#include <stdio.h>

int main() {
  
  printf("What is stored at %X? \n", ((int)(main)+0x100));

  return 0;
}

// 00001230: 0000 0000 0000 4865 6c6c 6f3f 2043 616e  ......Hello? Can
// 00001240: 2079 6f75 2073 6565 206d 653f 0000 4920   you see me?..I
// 00001250: 616d 2070 7265 7474 7920 676f 6f64 2100  am pretty good!.
