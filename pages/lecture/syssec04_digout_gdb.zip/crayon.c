#include <stdio.h>

int main() {
  char str[16];
  
  printf("G-Dragon, you seeing this? ");
  scanf("%s",str);

  return 0;
}

void flag(){
  puts("\nGet your crayon!\n");
}
