#include <stdio.h>

void icecream(){
  char str[16];
  puts("What is your favorit icecream?");
  gets(str);
}

int main() {
  icecream();
  return 0;
}

void flag(){
  puts("\nI like a vanlia icecream!\n");
}
