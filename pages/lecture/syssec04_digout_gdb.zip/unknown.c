#include <stdio.h>

void frozen(){
  int canary = 0xDEADBEEF;
  char str[17];

  puts("Elsa? Do you wanna build a snowman?");
  gets(str);

  if(canary != 0xDEADBEEF){
    puts("Go away, Anna!");
    exit(1);
  }
}

int main(){
  frozen();
}

void flag(){
  puts("\nInto the unknown~~~ \n");
}
