#include <stdio.h>

int main(){
  char *ptr = (char *)main; 
  int num;
  printf("I point a wrong position, the main '0x%X'... fix me! \n", ptr);
  scanf("%d", &num);
  
  ptr = (char*)((int)ptr + num);

  printf(ptr);

  return 0;
}
